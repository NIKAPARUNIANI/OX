const users = [
    {
        role: 'ADMIN',
        active: false,
        avatar: 'url1',
        confirmed: true
    },
    {
        role: 'USER',
        active: true,
        avatar: 'url2',
        confirmed: false
    },
    {
        role: 'ADMIN',
        active: true,
        avatar: 'url3',
        confirmed: true
    },
    {
        role: 'USER',
        active: false,
        avatar: 'url4',
        confirmed: true
    }
];

let admins = [];

// for(let i = 0; i < users.length; i++){
//     console.log(users[i]);

//     if(users[i].role === 'ADMIN'){
//         admins.push(users[i]);
//     }
// }


// users.forEach((user) => console.log(user));


// for(let user of users){
//     console.log(user);

//     if(user.role === 'ADMIN'){
//         admins.push(user);
//     }
// }


// for(let i in users){
//     console.log(users[i]);

//     if(users[i].role === 'ADMIN'){
//         admins.push(users[i]);
//     }
// }

// console.log(admins);